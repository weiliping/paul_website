<?php
    echo 'Permission Denied. <a href="http://wwww.amazingwei.com">Paul Wei</a>'
?>